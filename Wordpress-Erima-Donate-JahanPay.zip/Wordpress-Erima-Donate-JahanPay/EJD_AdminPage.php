﻿<?php 

defined('ABSPATH') or die('Access denied!');

if ( $_POST ) {
	
	if ( isset($_POST['EJD_MerchantID']) ) {
		update_option( 'EJD_MerchantID', $_POST['EJD_MerchantID'] );
	}
	
	if ( isset($_POST['EJD_IsOK']) ) {
		update_option( 'EJD_IsOK', $_POST['EJD_IsOK'] );
	}
  
	if ( isset($_POST['EJD_IsError']) ) {
		update_option( 'EJD_IsError', $_POST['EJD_IsError'] );
	}
	
  if ( isset($_POST['EJD_Unit']) ) {
		update_option( 'EJD_Unit', $_POST['EJD_Unit'] );
	}
  
  if ( isset($_POST['EJD_UseCustomStyle']) ) {
		update_option( 'EJD_UseCustomStyle', 'true' );
    
    if ( isset($_POST['EJD_CustomStyle']) )
    {
      update_option( 'EJD_CustomStyle', strip_tags($_POST['EJD_CustomStyle']) );
    }
    
	}
  else
  {
    update_option( 'EJD_UseCustomStyle', 'false' );
  }
  
	echo '<div class="updated" id="message"><p><strong>تنظیمات ذخیره شد</strong>.</p></div>';
	
}
?>
<h2 id="add-new-user">تنظیمات افزونه حمایت مالی - جهان پی</h2>
<h2 id="add-new-user">جمع تمام پرداخت ها : <?php echo get_option("EJD_TotalAmount"); ?>  تومان</h2>
<form method="post">
  <table class="form-table">
    <tbody>
      <tr class="user-first-name-wrap">
        <th><label for="EJD_MerchantID">کد دروازه پرداخت</label></th>
        <td>
          <input type="text" class="regular-text" value="<?php echo get_option( 'EJD_MerchantID'); ?>" id="EJD_MerchantID" name="EJD_MerchantID">
          <p class="description indicator-hint">XXXXXXXXXXXXX</p>
        </td>
      </tr>
      <tr>
        <th><label for="EJD_IsOK">پرداخت صحیح</label></th>
        <td><input type="text" class="regular-text" value="<?php echo get_option( 'EJD_IsOK'); ?>" id="EJD_IsOK" name="EJD_IsOK"></td>
      </tr>
      <tr>
        <th><label for="EJD_IsError">خطا در پرداخت</label></th>
        <td><input type="text" class="regular-text" value="<?php echo get_option( 'EJD_IsError'); ?>" id="EJD_IsError" name="EJD_IsError"></td>
      </tr>
      
      <tr class="user-display-name-wrap">
        <th><label for="EJD_Unit">واحد پول</label></th>
        <td>
          <?php $EJD_Unit = get_option( 'EJD_Unit'); ?>
          <select id="EJD_Unit" name="EJD_Unit">
            <option <?php if($EJD_Unit == 'تومان' ) echo 'selected="selected"' ?>>تومان</option>
            <option <?php if($EJD_Unit == 'ریال' ) echo 'selected="selected"' ?>>ریال</option>
          </select>
        </td>
      </tr>
      
      <tr class="user-display-name-wrap">
        <th>استفاده از استایل سفارشی</th>
        <td>
          <?php $EJD_UseCustomStyle = get_option('EJD_UseCustomStyle') == 'true' ? 'checked="checked"' : ''; ?>
          <input type="checkbox" name="EJD_UseCustomStyle" id="EJD_UseCustomStyle" value="true" <?php echo $EJD_UseCustomStyle ?> /><label for="EJD_UseCustomStyle">استفاده از استایل سفارشی برای فرم</label><br>
        </td>
      </tr>
      
      
      <tr class="user-display-name-wrap" id="EJD_CustomStyleBox" <?php if(get_option('EJD_UseCustomStyle') != 'true') echo 'style="display:none"'; ?>>
        <th>استایل سفارشی</th>
        <td>
          <textarea style="width: 90%;min-height: 400px;direction:ltr;" name="EJD_CustomStyle" id="EJD_CustomStyle"><?php echo get_option('EJD_CustomStyle') ?></textarea><br>
        </td>
      </tr>
      
    </tbody>
  </table>
  <p class="submit"><input type="submit" value="به روز رسانی تنظیمات" class="button button-primary" id="submit" name="submit"></p>
</form>

<script>
  if(typeof jQuery == 'function')
  {
    jQuery("#EJD_UseCustomStyle").change(function(){
      if(jQuery("#EJD_UseCustomStyle").prop('checked') == true)
        jQuery("#EJD_CustomStyleBox").show(500);
      else
        jQuery("#EJD_CustomStyleBox").hide(500);
    });
  }
</script>

