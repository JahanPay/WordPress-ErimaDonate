﻿<?php
session_start();
/*
Plugin Name: Erima JahanPay Donate - حمایت مالی 
Plugin URI: http://jahanpay.me
Description: افزونه حمایت مالی از وبسایت ها -- برای استفاده تنها کافی است کد زیر را درون بخشی از برگه یا نوشته خود قرار دهید  [ErimaJahanpayDonate]
Version: 1.0
Author:  جهان پي
Author URI: http://Jahanpay.me
*/

defined('ABSPATH') or die('Access denied!');
define ('ErimaJahanpayDonateDIR', plugin_dir_path( __FILE__ ));
define ('LIBDIR'  , ErimaJahanpayDonateDIR.'/lib');
define ('TABLE_DONATE'  , 'erima_donate');

require_once ABSPATH . 'wp-admin/includes/upgrade.php';

if ( is_admin() )
{
        add_action('admin_menu', 'EJD_AdminMenuItem');
        function EJD_AdminMenuItem()
        {
				add_menu_page( 'تنظیمات افزونه حمایت مالی - جهان پی', 'حمات مالی', 'administrator', 'EJD_MenuItem', 'EJD_MainPageHTML','', 6 ); 
        add_submenu_page('EJD_MenuItem','نمایش حامیان مالی','نمایش حامیان مالی', 'administrator','EJD_Hamian','EJD_HamianHTML');
        }
}

function EJD_MainPageHTML()
{
	include('EJD_AdminPage.php');
}

function EJD_HamianHTML()
{
	include('EJD_Hamian.php');
}


add_action( 'init', 'ErimaJahanpayDonateShortcode');
function ErimaJahanpayDonateShortcode(){
	add_shortcode('ErimaJahanpayDonate', 'ErimaJahanpayDonateForm');
}

function ErimaJahanpayDonateForm() {
  $out = '';
  $error = '';
  $message = '';
  
	$MerchantID = get_option( 'EJD_MerchantID');
  $EJD_IsOK = get_option( 'EJD_IsOK');
  $EJD_IsError = get_option( 'EJD_IsError');
  $EJD_Unit = get_option( 'EJD_Unit');
  
  $Amount = '';
  $Description = '';
  $Name = '';
  $Mobile = '';
  $Email = '';
  
  if(isset($_POST['submit']) && $_POST['submit'] == 'پرداخت')
  {
    
    if($MerchantID == '')
    {
      $error = 'کد دروازه پرداخت وارد نشده است' . "<br>\r\n";
    }
    
    
    $Amount = filter_input(INPUT_POST, 'EJD_Amount', FILTER_SANITIZE_SPECIAL_CHARS);
    
    if(is_numeric($Amount) != false)
    {
      if($EJD_Unit == 'ریال')
        $SendAmount =  $Amount / 10;
      else
        $SendAmount =  $Amount;
    }
    else
    {
      $error .= 'مبلغ به درستی وارد نشده است' . "<br>\r\n";
    }
    
    $Description =    filter_input(INPUT_POST, 'EJD_Description', FILTER_SANITIZE_SPECIAL_CHARS);  // Required
    $Name =           filter_input(INPUT_POST, 'EJD_Name', FILTER_SANITIZE_SPECIAL_CHARS);  // Required
    $Mobile =         filter_input(INPUT_POST, 'mobile', FILTER_SANITIZE_SPECIAL_CHARS); // Optional
    $Email =          filter_input(INPUT_POST, 'email', FILTER_SANITIZE_SPECIAL_CHARS); // Optional
    
    $SendDescription = $Name . ' | ' . $Mobile . ' | ' . $Email . ' | ' . $Description ;  
    
    if($error == '') 
    {
      $CallbackURL = EJD_GetCallBackURL(); 
      
      
   $client = new SoapClient("http://jpws.me/directservice?wsdl");
   $invoice_id=rand(10000000,90000000);
   $res = $client->requestpayment($MerchantID , $SendAmount , $CallbackURL , $invoice_id );
   
   $_SESSION["invoice_id"]=$invoice_id;
   $_SESSION["au"]=$res["au"];

      if(!empty($res["result"]) AND $res["result"]==1)
      {
        
        EJD_AddDonate(array(
					'Authority'     => $res["au"],
					'Name'          => $Name,
					'AmountTomaan'  => $SendAmount,
					'Mobile'        => $Mobile,
					'Email'         => $Email,
					'InputDate'     => current_time( 'mysql' ),
					'Description'   => $Description,
					'Status'        => 'SEND'
        ),array(
          '%s',
          '%s',
          '%d',
          '%s',
          '%s',
          '%s',
          '%s',
          '%s'
        ));
        
 
	 echo "<div style='display:none'>".$res['form']."</div>Please wait ... <script language='javascript'>document.jahanpay.submit(); </script>";
      } 
      else 
      {
        $error .= EJD_GetResaultStatusString($res["result"]) . "<br>\r\n";
      }
    }
  }

  if(isset($_SESSION['au']))
  {
        $Authority=$_SESSION['au'];
		$invoice_id=$_SESSION['invoice_id'];
    
        
      $Record = EJD_GetDonate($Authority);
      if( $Record  === false)
      {
        $error .= 'چنین تراکنشی در سایت ثبت نشده است' . "<br>\r\n";
      }
      else
      {
        $client = new SoapClient("http://724pay.net/directservice?wsdl");
$res = $client->verification($MerchantID , $Record['AmountTomaan'] , $Authority , $invoice_id, $_POST + $_GET );

        
        if($res["result"] == 1)
        {
          EJD_ChangeStatus($Authority, 'OK');
          $message .= get_option( 'EJD_IsOk') . "<br>\r\n";
          $message .= 'کد پیگیری تراکنش:'. $Authority . "<br>\r\n";
          
          $EJD_TotalAmount = get_option("EJD_TotalAmount");
          update_option("EJD_TotalAmount" , $EJD_TotalAmount + $Record['AmountTomaan']);
        } 
        else 
        {
          EJD_ChangeStatus($Authority, 'ERROR');
          $error .= get_option( 'EJD_IsError') . "<br>\r\n";
          $error .= EJD_GetResaultStatusString($res["result"]) . "<br>\r\n";
        }
      }
  
  }
  
  $style = '';
  
  if(get_option('EJD_UseCustomStyle') == 'true')
  {
    $style = get_option('EJD_CustomStyle');
  }
  else
  {
    $style = '#EJD_MainForm {  width: 400px;  height: auto;  margin: 0 auto;  direction: rtl; }  #EJD_Form {  width: 96%;  height: auto;  float: right;  padding: 10px 2%; }  #EJD_Message,#EJD_Error {  width: 90%;  margin-top: 10px;  margin-right: 2%;  float: right;  padding: 5px 2%;  border-right: 2px solid #006704;  background-color: #e7ffc5;  color: #00581f; }  #EJD_Error {  border-right: 2px solid #790000;  background-color: #ffc9c5;  color: #580a00; }  .EJD_FormItem {  width: 90%;  margin-top: 10px;  margin-right: 2%;  float: right;  padding: 5px 2%; }    .EJD_FormLabel {  width: 35%;  float: right;  padding: 3px 0; }  .EJD_ItemInput {  width: 64%;  float: left; }  .EJD_ItemInput input {  width: 90%;  float: right;  border-radius: 3px;  box-shadow: 0 0 2px #00c4ff;  border: 0px solid #c0fff0;  font-family: inherit;  font-size: inherit;  padding: 3px 5px; }  .EJD_ItemInput input:focus {  box-shadow: 0 0 4px #0099d1; }  .EJD_ItemInput input.error {  box-shadow: 0 0 4px #ef0d1e; }  input.EJD_Submit {  background: none repeat scroll 0 0 #2ea2cc;  border-color: #0074a2;  box-shadow: 0 1px 0 rgba(120, 200, 230, 0.5) inset, 0 1px 0 rgba(0, 0, 0, 0.15);  color: #fff;  text-decoration: none;  border-radius: 3px;  border-style: solid;  border-width: 1px;  box-sizing: border-box;  cursor: pointer;  display: inline-block;  font-size: 13px;  line-height: 26px;  margin: 0;  padding: 0 10px 1px;  margin: 10px auto;  width: 50%;  font: inherit;  float: right;  margin-right: 24%; }';
  }
  
  
	$out = '
  <style>
    '. $style . '
  </style>
      <div style="clear:both;width:100%;float:right;">
	        <div id="EJD_MainForm">
          <div id="EJD_Form">';
          
if($message != '')
{    
    $out .= "<div id=\"EJD_Message\">
    ${message}
            </div>";
}

if($error != '')
{    
    $out .= "<div id=\"EJD_Error\">
    ${error}
            </div>";
}

     $out .=      '<form method="post">
              <div class="EJD_FormItem">
                <label class="EJD_FormLabel">مبلغ :</label>
                <div class="EJD_ItemInput">
                  <input style="width:60%" type="text" name="EJD_Amount" value="'. $Amount .'" />
                  <span style="margin-right:10px;">'. $EJD_Unit .'</span>
                </div>
              </div>
              
              <div class="EJD_FormItem">
                <label class="EJD_FormLabel">نام و نام خانوادگی :</label>
                <div class="EJD_ItemInput"><input type="text" name="EJD_Name" value="'. $Name .'" /></div>
              </div>
              
              <div class="EJD_FormItem">
                <label class="EJD_FormLabel">تلفن همراه :</label>
                <div class="EJD_ItemInput"><input type="text" name="mobile" value="'. $Mobile .'" /></div>
              </div>
              
              <div class="EJD_FormItem">
                <label class="EJD_FormLabel">ایمیل :</label>
                <div class="EJD_ItemInput"><input type="text" name="email" style="direction:ltr;text-align:left;" value="'. $Email .'" /></div>
              </div>
              
              <div class="EJD_FormItem">
                <label class="EJD_FormLabel">توضیحات :</label>
                <div class="EJD_ItemInput"><input type="text" name="EJD_Description" value="'. $Description .'" /></div>
              </div>
              
              <div class="EJD_FormItem">
                <input type="submit" name="submit" value="پرداخت" class="EJD_Submit" />
              </div>
              
            </form>
          </div>
        </div>
      </div>
	';
  
  return $out;
}


register_activation_hook(__FILE__,'EriamJahanpayDonate_install');
function EriamJahanpayDonate_install()
{
	EJD_CreateDatabaseTables();
}
function EJD_CreateDatabaseTables()
{
		global $wpdb;
		$erimaDonateTable = $wpdb->prefix . TABLE_DONATE;

		$nazrezohoor = "CREATE TABLE IF NOT EXISTS `$erimaDonateTable` (
					  `DonateID` int(11) NOT NULL AUTO_INCREMENT,
					  `Authority` varchar(50) NOT NULL,
					  `Name` varchar(50) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
					  `AmountTomaan` int(11) NOT NULL,
					  `Mobile` varchar(11) ,
					  `Email` varchar(50),
					  `InputDate` varchar(20),
					  `Description` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci,
					  `Status` varchar(5),
					  PRIMARY KEY (`DonateID`),
					  KEY `DonateID` (`DonateID`)
					) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
		dbDelta($nazrezohoor);

		add_option("EJD_TotalAmount", 0, '', 'yes');
		add_option("EJD_TotalPayment", 0, '', 'yes');
		add_option("EJD_IsOK", 'با تشکر پرداخت شما به درستی انجام شد.', '', 'yes');
		add_option("EJD_IsError", 'متاسفانه پرداخت انجام نشد.', '', 'yes');
    
    $style = '#EJD_MainForm {
  width: 400px;
  height: auto;
  margin: 0 auto;
  direction: rtl;
}

#EJD_Form {
  width: 96%;
  height: auto;
  float: right;
  padding: 10px 2%;
}

#EJD_Message,#EJD_Error {
  width: 90%;
  margin-top: 10px;
  margin-right: 2%;
  float: right;
  padding: 5px 2%;
  border-right: 2px solid #006704;
  background-color: #e7ffc5;
  color: #00581f;
}

#EJD_Error {
  border-right: 2px solid #790000;
  background-color: #ffc9c5;
  color: #580a00;
}

.EJD_FormItem {
  width: 90%;
  margin-top: 10px;
  margin-right: 2%;
  float: right;
  padding: 5px 2%;
}

.EJD_FormLabel {
  width: 35%;
  float: right;
  padding: 3px 0;
}

.EJD_ItemInput {
  width: 64%;
  float: left;
}

.EJD_ItemInput input {
  width: 90%;
  float: right;
  border-radius: 3px;
  box-shadow: 0 0 2px #00c4ff;
  border: 0px solid #c0fff0;
  font-family: inherit;
  font-size: inherit;
  padding: 3px 5px;
}

.EJD_ItemInput input:focus {
  box-shadow: 0 0 4px #0099d1;
}

.EJD_ItemInput input.error {
  box-shadow: 0 0 4px #ef0d1e;
}

input.EJD_Submit {
  background: none repeat scroll 0 0 #2ea2cc;
  border-color: #0074a2;
  box-shadow: 0 1px 0 rgba(120, 200, 230, 0.5) inset, 0 1px 0 rgba(0, 0, 0, 0.15);
  color: #fff;
  text-decoration: none;
  border-radius: 3px;
  border-style: solid;
  border-width: 1px;
  box-sizing: border-box;
  cursor: pointer;
  display: inline-block;
  font-size: 13px;
  line-height: 26px;
  margin: 0;
  padding: 0 10px 1px;
  margin: 10px auto;
  width: 50%;
  font: inherit;
  float: right;
  margin-right: 24%;
}';
  add_option("EJD_CustomStyle", $style, '', 'yes');
  add_option("EJD_UseCustomStyle", 'false', '', 'yes');
}

function EJD_GetDonate($Authority)
{
  global $wpdb;
  $Authority = strip_tags($wpdb->escape($Authority));
  
  if($Authority == '')
    return false;
  
	$erimaDonateTable = $wpdb->prefix . TABLE_DONATE;

  $res = $wpdb->get_results( "SELECT * FROM ${erimaDonateTable} WHERE Authority = '${Authority}' LIMIT 1",ARRAY_A);
  
  if(count($res) == 0)
    return false;
  
  return $res[0];
}

function EJD_AddDonate($Data, $Format)
{
  global $wpdb;

  if(!is_array($Data))
    return false;
  
	$erimaDonateTable = $wpdb->prefix . TABLE_DONATE;

  $res = $wpdb->insert( $erimaDonateTable , $Data, $Format);
  
  if($res == 1)
  {
    $totalPay = get_option('EJD_TotalPayment');
    $totalPay += 1;
    update_option('EJD_TotalPayment', $totalPay);
  }
  
  return $res;
}

function EJD_ChangeStatus($Authority,$Status)
{
  global $wpdb;
  $Authority = strip_tags($wpdb->escape($Authority));
  $Status = strip_tags($wpdb->escape($Status));
  
  if($Authority == '' || $Status == '')
    return false;
  
	$erimaDonateTable = $wpdb->prefix . TABLE_DONATE;

  $res = $wpdb->query( "UPDATE ${erimaDonateTable} SET `Status` = '${Status}' WHERE `Authority` = '${Authority}'");
  
  return $res;
}

function EJD_GetResaultStatusString($StatusNumber)
{
  switch($StatusNumber)
  {
case '-20' :
				return 'api نامعتبر است .';
							case '-21' :
				return 'آی پی نامعتبر است .';
							case '-22' :
				return 'مقدار مبلغ نباید کمتر از 1000 ریال باشد .';
							case '-23' :
				return 'مبلغ از سقف تعریف شده بیشتر است .';
							case '-24' :
				return 'مبلغ نامعتبر است .';
							case '-6' :
				return 'ارتباط با بانک برقرار نشد .';
							case '-26' :
				return 'درگاه غیرفعال است .';
							case '-27' :
				return 'آی پی شما مسدود است .';
							case '-9' :
				return 'خطای ناشناخته .';
							case '-29' :
				return 'آدرس بازگشت از بانک نامعتبر است .';
							case '-30' :
				return 'چنین تراکنشی یافت نشد .';
							case '-31' :
				return 'تراکنش انجام نشده .';
							case '-32' :
				return 'تراکنش انجام شده اما مبلغ نادرست است .';
							case '1' :
				return 'تراکنش با موفقیت انجام شده است .';
							case '-33' :
				return 'api مربوط به درگاه اختصاصی مستقیم است ، باید از وبسرویس درگاه عادی استفاده کنید .';
							case '-34' :
				return 'درگاه شما درگاه عادی است ، باید به وبسرویس عادی متصل شوید .';
							case '-35' :
				return 'شماره order_id نامعتبر است .';
							case '-36' :
				return 'پارامترهای ارسالی بانکی نامعتبر هستند .';
							case '-38' :
				return 'تراکنش قبلا یکبار verify شده .';
			
  }
  
  return '';
}

function EJD_GetCallBackURL()
{
  $pageURL = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
  
  $ServerName = htmlspecialchars($_SERVER["SERVER_NAME"], ENT_QUOTES, "utf-8");
  $ServerPort = htmlspecialchars($_SERVER["SERVER_PORT"], ENT_QUOTES, "utf-8");
  $ServerRequestUri = htmlspecialchars($_SERVER["REQUEST_URI"], ENT_QUOTES, "utf-8");
  
  if ($_SERVER["SERVER_PORT"] != "80")
  {
      $pageURL .= $ServerName .":". $ServerPort . $_SERVER["REQUEST_URI"];
  } 
  else 
  {
      $pageURL .= $ServerName . $ServerRequestUri;
  }
  return $pageURL;
}

?>
